



public class HospitalManagement {

    
    public static void main(String[] args)throws ClassNotFoundException {
         java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePage().setVisible(true);
            }
        });
      
    }
    
}
